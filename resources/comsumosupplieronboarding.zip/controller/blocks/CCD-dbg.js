sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	return BlockBase.extend("com.sumo.supplieronboarding.view.blocks.CCD", {
		metadata: {
			/* no additional views provided */
		}
	});
});
