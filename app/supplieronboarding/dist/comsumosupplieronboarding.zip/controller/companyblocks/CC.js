sap.ui.define(["sap/uxap/BlockBase"],function(e){"use strict";return e.extend("com.sumo.supplieronboarding.view.companyblocks.CC",{metadata:{}})});
//# sourceMappingURL=CC.js.map