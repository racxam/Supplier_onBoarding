sap.ui.define(["sap/uxap/BlockBase"],function(e){"use strict";return e.extend("com.sumo.supplieronboarding.view.blocks.CIRD",{metadata:{}})});
//# sourceMappingURL=CIRD.js.map