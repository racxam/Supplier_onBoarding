sap.ui.define(["sap/uxap/BlockBase"],function(e){"use strict";return e.extend("com.sumo.supplieronboarding.view.blocks.payment",{metadata:{}})});
//# sourceMappingURL=payment.js.map