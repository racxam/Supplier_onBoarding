sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	return BlockBase.extend("com.sumo.supplieronboarding.view.blocks.CIRD", {
		metadata: {
			/* no additional views provided */
		}
	});
});
